package String_pro;

public class char_to_string {
	public static void main(String[] args) {
		char c[]= {'a','b','c','d'};
		String s=new String(c);
		System.out.println(s);
	}
}
