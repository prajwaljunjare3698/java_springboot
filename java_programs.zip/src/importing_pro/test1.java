package importing_pro;

public class test1 {
	public static void main(String[] args) {
		int arr[] = {3,4,2,1,5};
		test.max(arr);
		test.min(arr);
	}
}	
