package multi_threading;

public class multi_task2 extends Thread{
	public void run() {
		System.out.println("task2");
	}
}
