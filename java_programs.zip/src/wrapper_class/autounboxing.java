package wrapper_class;
public class autounboxing {
	public static void main(String[] args) {
		Byte b = 10;
		byte c = b;
		System.out.println(c);
	}
}
