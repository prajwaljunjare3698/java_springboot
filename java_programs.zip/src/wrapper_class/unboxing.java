package wrapper_class;

public class unboxing {
	public static void main(String[] args) {
		Byte b = 10;
		byte c = b.byteValue();
		System.out.println(c+10);
		
		Integer i =120;
		int j = i.intValue();
		System.out.println(j+c);
		
		Boolean flag = true;
		boolean count = flag.booleanValue();
		System.out.println(count);
		
		
	}
}	
