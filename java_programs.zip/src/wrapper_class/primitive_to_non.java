package wrapper_class;

public class primitive_to_non {
	public static void main(String[] args) {
		byte b = 10;
		Byte c = Byte.valueOf(b);
		System.out.println(c);
	}
}
