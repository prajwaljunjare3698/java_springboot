package DSA;

public class count_no {
	public static void main(String[] args) {
		count();
	}
	public static void count() {
		int sum = 0;
		for(int i=1; i<=100; i++) {
			int a = i;
			while(a>0) {
				int temp = a%10;
				if(temp==2) {
					sum++;
				}
				a=a/10;
			}
		}
		System.out.println(sum);
	}
	
	
}
