package DSA;

public class quick_sort {
	public static void main(String[] args) {
		int arr[] = {10,15,1,2,9,16,11};
		int arr1[] = {1,2,3,4};		
		int piv = arr[0];
		int start = arr[0];
		int end = arr.length-1;
		quicksort(piv,start,end);
	}
	public static void quicksort(int piv,int start,int end) {
		if(start<end) {
				
			
		}
	}	
}
