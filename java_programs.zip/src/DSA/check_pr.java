package DSA;

public class check_pr {
	public static void main(String[] args) {
		int b = 5;
		for(int i=0; i<=b; i++) {
			if(i>=1) {
				b = b-5;	
			}
			System.out.println(i);	
			i++;
		}
	}
}
