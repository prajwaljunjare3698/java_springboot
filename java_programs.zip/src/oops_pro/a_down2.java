package oops_pro;

public class a_down2 extends a_down1 {
	int b= 10;
	public static void main(String[] args) {
		a_down1 a = new a_down1();
		a_down2 a1 = (a_down2)a;
		System.out.println(a1.a);
		
	}
}
