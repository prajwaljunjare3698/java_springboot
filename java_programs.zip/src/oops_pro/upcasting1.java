package oops_pro;

public class upcasting1 {
	int a =10;
}
