package oops_pro;

public class Car_runner {
	public static void main(String[] args) {
		Car_data c1 = new Car_data("suzuki","i10","tata group",500);
		Car_data c2 = new Car_data("maruti","verna","lyland",200);
		Car_data c3 = new Car_data("BMW","130P","abc",600);
		c1.show();
		c2.show();
		c3.show();
	}
}
