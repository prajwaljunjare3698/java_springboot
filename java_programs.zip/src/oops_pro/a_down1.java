package oops_pro;

public class a_down1 {
	int a = 10;
}
