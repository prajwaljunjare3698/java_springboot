package oops_pro;

public class super_keyword1 {
	int a =10;
	String s = "abc";
	
	super_keyword1(){
		this.a=20;
		this.s="xyz";
	}
	
}
