package Arrays_pro;

public class ArrayStoreException1 {

}
