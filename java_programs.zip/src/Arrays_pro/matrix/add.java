package Arrays_pro.matrix;

public class add {
	public static void main(String[] args) {
		int a[]= {1,2,3,4};
		int b[]= {12,5,6,9};
		
		for(int i=0;i<a.length;i++) {
			int sum=0;
			sum=a[i]+b[i];
			System.out.println(sum);
		}
		
	}
}
