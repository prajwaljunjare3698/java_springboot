package shubham;

public class akshya {
	public static void main(String[] args) {
		String s = "ababcadabbac";
		String s1 = "";
		int i=0;
		while(true) {
			if(i<s.length()) {
				
			}
		}
	}
}	
