package shubham;

import java.io.File;

public class exception{
	public static void main(String[] args) throws InterruptedException {
		Thread.sleep(100);
		
		//primiteiv to Non
//		int a = 10;
//		Integer j = Integer.valueOf(a);
//		System.out.println(a);
//		
		//autoboxing
//		int c = 10;
//		Integer d = c;
//		System.out.println(d);
		
		//unboxing
//		Integer i = 10;
//		int j = i.intValue();
//		System.out.println(j);
		
		//autounblxing
//		Integer e = 20;
//		int f = e;
//		System.out.println(f);
		
	}
}
