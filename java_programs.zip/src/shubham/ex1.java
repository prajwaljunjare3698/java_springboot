package shubham;

public class ex1 {
	public static void main(String[] args) {
		System.out.println("hi");
	}
}
