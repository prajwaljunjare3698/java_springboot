package Project;

public class ButterChicken  extends Food{

}
