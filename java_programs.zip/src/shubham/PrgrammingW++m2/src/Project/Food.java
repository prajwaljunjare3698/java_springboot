package Project;

public class Food {

}
