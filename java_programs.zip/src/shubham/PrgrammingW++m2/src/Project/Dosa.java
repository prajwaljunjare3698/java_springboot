package Project;

public class Dosa extends Food{

}
