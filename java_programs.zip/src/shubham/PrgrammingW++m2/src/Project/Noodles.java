package Project;

public class Noodles  extends Food {

}
