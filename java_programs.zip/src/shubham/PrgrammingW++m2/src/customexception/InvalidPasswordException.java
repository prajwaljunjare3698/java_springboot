package customexception;

public class InvalidPasswordException extends RuntimeException {

}
