package customexception;

public class InsufficientBalanceException extends RuntimeException {

}
