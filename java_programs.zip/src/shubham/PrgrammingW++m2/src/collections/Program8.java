package collections;

import java.util.ArrayList;

public class Program8 {
	public static void main(String[] args) {
		ArrayList<Integer> l = new ArrayList<Integer>();
		l.add(10);
		l.add(20);
		l.add(30);
		for(int i:l)
		{
			System.out.println(i);
		}
		for(Integer i1 :l)
		{
			System.out.println(i1);
		}
		ArrayList<Double> al = new ArrayList();
		al.add(12.34567);
		al.add(12345.678);
		
		}
 // arraylist can only store int type
// collection doesnt support primitive version of datatype
}
