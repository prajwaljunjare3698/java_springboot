package collections;

import java.util.TreeSet;

public class Program16 {
	public static void main(String[] args) {
		TreeSet t = new TreeSet();
		
		t.add(10);
		t.add(12.34);
		t.add("java");
		System.out.println(t);
	}

}
