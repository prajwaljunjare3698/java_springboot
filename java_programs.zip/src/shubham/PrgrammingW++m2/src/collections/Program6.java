package collections;

public class Program6 {
	public static void main(String[] args) {
		// primitive version
		int a =10;
		
		// non primitive
		Integer b =  new Integer(10);
		System.out.println(a +" "+b);
		System.out.println("--------------");
		
		char c='A';
		Character d = new Character('A');
		System.out.println(c +" "+ d);
		
		//wrapper class tostring method is overidden
		// wapper class in represent java.lang.pack
	}

}
