package collections;

import java.util.ArrayList;

public class Program1 {
	public static void main(String[] args) {
		ArrayList l = new ArrayList();
		l.add(10);
		l.add(1.23);
		l.add(10);
		l.add("java");
		l.add(null);
		System.out.println(l);
		
	}

}
