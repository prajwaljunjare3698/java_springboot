package collections;

import java.util.TreeSet;

public class Program14 {
	public static void main(String[] args) {
		TreeSet t = new TreeSet();
		t.add('B');
		t.add('A');
		t.add('C');
		
		System.out.println(t);
	}

}
