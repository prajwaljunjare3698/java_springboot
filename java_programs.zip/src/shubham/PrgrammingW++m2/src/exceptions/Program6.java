package exceptions;

public class Program6 {
	public static void main(String[] args) {
		try {
			try {
				
			} catch (Exception e) {
	// we can have nested try and catch block
			}
			
		} catch (Exception e) {
		
		}
finally {
	try {
	// we can have try and catch block inside finally block
	} 
	catch (Exception e2) {
		
	}
	
}
	}

}
