package exception_pro;

import java.io.File;

public class checked_exce1 {
//	public static void main(String[] args) throws IoException {
//		File f = new File("C://abdc.txt");
//		f.createNewFile();
//	}
}
