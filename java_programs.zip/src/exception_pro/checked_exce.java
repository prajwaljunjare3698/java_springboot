package exception_pro;

public class checked_exce {
	public static void main(String[] args) throws InterruptedException
	{
		Thread.sleep(100);
		System.out.println("exet");
		
	}
}
