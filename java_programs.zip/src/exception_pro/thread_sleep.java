package exception_pro;

public class thread_sleep {
	public static void main(String[] args) {
		//Thread.sleep(100);
		//System.out.println(10/0);
//		try {
//			
//			System.out.println(10/0);
//			System.out.println("hi");
//		}
//		catch(Throwable e) {
//			System.out.println("d");
//			System.out.println(e);
//		}
		for(;;) {
			System.out.println("hi");
		}
		
	}
}
