package exception_pro;

public class custom_exception extends Exception{
	custom_exception(String s){
		super(s);
	}
}
