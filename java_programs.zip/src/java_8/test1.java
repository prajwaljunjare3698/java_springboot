package java_8;

public class test1 {
	public static void demo() {
		System.out.println("demo from test");
	}	
}
