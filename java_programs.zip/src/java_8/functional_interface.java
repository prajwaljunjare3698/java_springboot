package java_8;

@FunctionalInterface
public interface functional_interface {
	String getdata(String id,String pass);
	
}
