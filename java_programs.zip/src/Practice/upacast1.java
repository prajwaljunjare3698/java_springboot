package Practice;

public class upacast1 {
	
	int a = 10;
	public void display() {
		System.out.println("this is upcast1");
	}
}
