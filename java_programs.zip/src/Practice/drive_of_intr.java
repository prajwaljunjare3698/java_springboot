package Practice;

public class drive_of_intr extends intrB implements interface1 {
	public static void main(String[] args) {
		drive_of_intr d = new drive_of_intr();
		
		//d.m1();s
	}
}
