package Practice;

public class random_no {
	public static void main(String[] args) {
		int a=(int)(Math.random()*(8-1+1));
		System.out.println(a);
	}
}
