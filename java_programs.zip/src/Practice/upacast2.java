package Practice;

public class upacast2 extends upacast1{
	int b = 20;
	public void display() {
		System.out.println("this is upcast 2");
	}
}
