package Practice;

public class tostring {
	int a = 10;
	public static void main(String[] args) {
		tostring s = new tostring();
		System.out.println(s);
	}
	public String toString() {
		return a+"";
	}
}
