package Practice;

public class equals {
	int a = 10;
	int b = 20;
	public static void main(String[] args) {
		equals e1 = new equals();
		equals e2 = new equals();
		System.out.println(e1.equals(e2));
	}
}
