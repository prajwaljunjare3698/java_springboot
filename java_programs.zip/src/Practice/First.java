package Practice;

public class First {
	public static void main(String[] args) {
		System.out.println("hii");
		my();
	}
	public static void my() {
		System.out.println("hello");
	}
}
