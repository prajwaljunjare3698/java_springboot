package Practice;

public class find_power {
	public static void main(String[] args) {
		int a = 2;
		int pow = 0;
		int result = 1;
		for(int i=1;i<=pow;i++) {
			result=result*a;
		}
		System.out.println(result);
		System.out.println((int)Math.pow(2, 3));
	}
}
