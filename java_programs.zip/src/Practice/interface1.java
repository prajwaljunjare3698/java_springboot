package Practice;

public interface interface1 {
	public static void m1() {
		System.out.println("from A");
	}
	//abstract public void m2();
}
