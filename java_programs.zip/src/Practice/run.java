package Practice;

public class run extends Upcasting {
	public static void main(String[] args) {
		Upcasting u = new Upcasting();
		u.printa();
	}
}
