package Practice;

public class intrB {
	public static void m1() {
		System.out.println("from B");
	}
}
