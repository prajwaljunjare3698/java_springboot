package Practice;
public class Upcasting {
 int a = 10;
		 public void printa() {
			 System.out.println(a);
		 }
	}
