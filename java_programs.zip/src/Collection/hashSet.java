package Collection;
import java.util.HashSet;
public class hashSet {
	public static void main(String[] args) {
		
		HashSet hash = new HashSet();
		hash.add(12);
		hash.add("kd");
		hash.add("d");
		hash.add("d");
		hash.add(null);
		
		System.out.println(hash);
	}

}
