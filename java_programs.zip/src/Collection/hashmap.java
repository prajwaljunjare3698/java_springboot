package Collection;
import java.util.HashMap;
public class hashmap {
	public static void main(String[] args) {
		
		HashMap h = new HashMap();
		h.put(1,"ram");
		h.put(2,"akshay");
		h.put(3, "pankaj");
		h.put(4, "shubham");
		h.put(5, "kuldeep");
		
		System.out.println(h);
	}
}
