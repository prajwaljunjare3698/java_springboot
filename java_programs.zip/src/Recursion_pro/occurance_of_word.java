package Recursion_pro;

import java.util.Arrays;

public class occurance_of_word {
	public static void main(String[] args) {
		String s = "hii hii to to my to my my my my hii to name hii is to hii";
		String s1 = "";		
		String a[]=s.split(" ");
		System.out.println(Arrays.toString(a));		
		String var="";
		int count=1;
		int pre=0;
		int eq=0;
		String first="";
		//String second="";
		for(int i=0;i<a.length;i++) {			
			for(int j=i+1;j<a.length;j++) {
				if(a[i].equals(a[j])) 
				{
					count++;
				}
				//System.out.println(count);
			}
			if(count>pre) {
				var=a[i];
				pre=count;
				count=1;
			}
			else if(count==pre) {
				first=var;
				eq=1;
			}
			else {
				count=1;
			}
		}
		if(eq!=0) {
			if(var.length()>first.length())
				System.out.println(var);
			else
				System.out.println(first);
		}
		else{
			System.out.println(var+"  ");
		}
	}
}
