package Recursion_pro;

public class no_factors {
	public static void main(String[] args) {
		int no = 26;
		factors(no,1);
	}
	public static void factors(int no,int i) {
		if(i<no) {
			if(no%i==0) {
				System.out.println(i);
			}
			factors(no,i+1);
		}
	}
}

