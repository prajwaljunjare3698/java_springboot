package Recursion_pro;

public class pra {
	public static void main(String[] args) {
		int a = 10;
		send(a);
		System.out.println(a);
	}
	public static void send(int a) {
		a=a+10;
		System.out.println(a);
	}
}
