package Recursion_pro;

public class binray_searcch {
	public static void main(String[] args) {
		int arr[] = {1,3,12,13,14,19,23,25};
		int item = 23;
		int beg = 0;
		int end = arr.length-1;
		int mid = 0;
		search(arr,item,beg,end,mid);
	}
	public static void search(int arr[],int item,int beg,int end,int mid) {
		mid = (beg+end)/2;
		if(arr[mid]==item) {
			System.out.println(mid);
		}
		else if(arr[beg]==item) {
			System.out.println(beg);
		}
		else if(arr[end]==item) {
			System.out.println(end);
		}
		else {
			if(arr[mid]<=item) {
				beg = mid+1;
			}
			else {
				end = mid-1;
			}
			search(arr,item,beg,end,mid);
		}		
	}
}
