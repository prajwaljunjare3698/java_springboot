package Recursion_pro;

import java.util.Scanner;

public class table_of_no {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int no = sc.nextInt();
		int i = 1;
		table(no,i);
		System.out.println("hii");
		sc.close();
	}
	public static void table(int no,int i) {
		if(i<=10) {
			System.out.println(no*i);
			table(no,i+1);
		}
		else {
			
			System.out.println(no);
		}
	}
	
}
