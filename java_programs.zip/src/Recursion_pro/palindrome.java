package Recursion_pro;

public class palindrome {
	public static void main(String[] args){		
	int no = 1234;	
	int rev = 0;
	int a = palindrome(no,rev);
	System.out.println(a);
	}
	public static int palindrome(int no,int rev){
		if(no>0){
			int temp = no%10;
			rev = rev*10+temp;
			return palindrome(no/10,rev);
		}
		return rev;
	}
}
