package Recursion_pro;

public class count_no {
	static int sum = 0;
	public static void main(String[] args) {
		int start=1;
		int end=100;
		count(start,end);
	}
	public static void count(int start,int end) {
		if(start==end) {
			System.out.println(sum);
		}
		else {
			get(start);
			count(start+1,end);
		}
	}
	public static void get(int start) {
		if(start>0) {
			int temp = start%10;
			if(temp==1) {
				sum++;
			}			
			start=start/10;
			get(start);
		}		
	}
}
