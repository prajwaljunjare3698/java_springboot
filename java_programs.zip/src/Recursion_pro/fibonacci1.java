package Recursion_pro;
import java.util.Scanner;
public class fibonacci1 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int no = sc.nextInt();
	boolean arr[] = new boolean[no];
	int arr_ind = 0;
	int i=1;
	while(i<=no) {
		int first=0;
		int second=1;
		int sum;
		int a=sc.nextInt();
		int count=0;
		if(a==0 || a==1) {
			arr[arr_ind]=true;
			arr_ind++;
		}
		else {
			for(int j=1;j<=a;j++) {
				sum=first+second;
				first=second;
				second=sum;
				if(sum==a) {
					arr[arr_ind]=true;
					count++;
					arr_ind++;
					break;
				}
			}
			if(count==0) {
				arr[arr_ind]=false;
				arr_ind++;
			}
		}
			i++;
		}
	for(int k=0;k<arr.length;k++) {
		System.out.println(arr[k]);
	}
	}
}
