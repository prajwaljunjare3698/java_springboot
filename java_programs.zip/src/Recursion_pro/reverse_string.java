package Recursion_pro;

public class reverse_string {
	public static void main(String[] args) {
	
	String s = "abcd";
	String s1 = "";
		
	int i = s.length()-1;
	reverse(s,s1,i);
	}
	public static void reverse(String s,String s1,int i) {
		if(i>=0) 
		{
			s1 = s1+s.charAt(i);
			reverse(s, s1, i-1);
		}
		else 
		{			
			System.out.println(s1);
		}
	}
}