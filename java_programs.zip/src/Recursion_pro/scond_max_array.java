package Recursion_pro;

public class scond_max_array {
	public static void main(String[] args) {
		int arr[] = {3,2,1,5};
		int max=arr[0];
		int max2=0;
		int i=0;
		int a = find(arr,max,max2,i);
		System.out.println(a);
	}
	public static int find(int arr[],int max,int max2,int i) {
		if(i<arr.length) {
			if(arr[i] > max) {
				max2 = max;
				max = arr[i];
			}
			if(arr[i]!=max && max2>arr[i]) {
				max2=arr[i];
			}
			return find(arr,max,max2,i+1);
		}
		return max2;	

	}
}
