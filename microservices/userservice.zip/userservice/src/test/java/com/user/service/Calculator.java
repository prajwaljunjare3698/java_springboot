package com.user.service;

public class Calculator {
	
	public int doSum(int a,int b) {
		return a+b;
	}
	
	public int doProduct(int a,int b) {
		return a*b;
	}
	public boolean checkSame(int a,int b) {
		return a==b;
	}
}
